/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Areej Fatima
 */
public class Truck extends Vehicle {
     private static List<Truck> availableTrucks = new ArrayList<>();

    public Truck(String name, double price, double mileage, int count) {
        super(name, price, mileage, count);
    }

    public void view() {
        // Display available trucks
        System.out.println("Available Trucks:");
        for (Truck truck : availableTrucks) {
            System.out.println(truck.name);
        }

        Scanner scanner = new Scanner(System.in);
        String action;

        do {
            System.out.println("Do you want to buy or rent a truck? (Type 'buy' or 'rent', or 'exit' to quit):");
            action = scanner.nextLine().toLowerCase();

            if (action.equals("exit")) {
                System.out.println("Thank you for using the system. Goodbye!");
                return; // Exit the method and stop the loop
            }

            if (action.equals("rent") || action.equals("buy")) {
                System.out.println("Enter the truck name:");
                String truckName = scanner.nextLine();

                boolean truckFound = false;
                for (Truck truck : availableTrucks) {
                    if (truck.name.equalsIgnoreCase(truckName)) {
                        if (action.equals("rent")) {
                            if (truck.count > 0) {
                                System.out.println("The truck '" + truck.name + "' is available for rent.");
                                // Simulating the booking process
                                truck.count--;
                                System.out.println("Truck booked for rent. Enjoy your ride!");
                            } else {
                                System.out.println("Sorry, the truck '" + truck.name + "' is not available for rent.");
                            }
                        } else if (action.equals("buy")) {
                            System.out.println("The truck '" + truck.name + "' is available for sale.");
                        }
                        truckFound = true;
                        break;
                    }
                }
                if (!truckFound) {
                    System.out.println("Sorry, the truck '" + truckName + "' is not available. you can go for another truck.");
                }
            } else {
                System.out.println("Invalid action. Please type 'buy' or 'rent', or 'exit' to quit.");
            }
        } while (true); // Loop will continue until 'exit' is entered
    }

    public static void addTruck(Truck truck) {
        availableTrucks.add(truck);
    }
}

