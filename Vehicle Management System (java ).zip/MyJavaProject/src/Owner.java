
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
import java.io.*;
import java.util.*;
/**
 *
 * @author Areej Fatima
 */
public class Owner {
    public String name;
    public String fatherName;
    public String idCardNumber;
    public String nationality;
    public String email;
    public String phoneNumber;
    
    public void addcar()
    {
        ArrayList<String> car = new ArrayList<>();
        car.add("Toyota Camry");
        car.add("Honda Civic");
        car.add("Toyota Corolla");
        car.add("Suzuki Grandi");
        car.add("Honda City");
        System.out.println(car);
        System.out.println("Please Enter Name of car you want to add");
        Scanner sc = new Scanner(System.in);
        String c = sc.nextLine();
        car.add(c);
         System.out.println("Addition Successfull you can see!");
        System.out.println(car);
        
        
    }
    public void deletecar()
    {
        ArrayList<String> car = new ArrayList<>();
        car.add("Toyota Camry");
        car.add("Honda Civic");
        car.add("Toyota Corolla");
        car.add("Suzuki Grandi");
        car.add("Honda City");
        System.out.println(car);
        System.out.println("Please Enter Name of car you want to delete");
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        car.remove(a);
         System.out.println("Deletion Successfull you can see!");
        System.out.println(car);
    }
    public void addtruck(){
         ArrayList<String> truck = new ArrayList<>();
        truck.add("Ford F-150");
        truck.add("Chevrolet Silverado");
        truck.add("Dodge Ram");
        
        System.out.println(truck);
        System.out.println("Please Enter Name of car you want to add");
        Scanner sc = new Scanner(System.in);
        String b = sc.nextLine();
        truck.add(b);
         System.out.println("Addition Successfull you can see!");
        System.out.println(truck);
    }
    
    public void deletetruck(){
        ArrayList<String> truck = new ArrayList<>();
        truck.add("Ford F-150");
        truck.add("Chevrolet Silverado");
        truck.add("Dodge Ram");
        
        System.out.println(truck);
        System.out.println("Please Enter Name of car you want to delete");
        Scanner sc = new Scanner(System.in);
        String d = sc.nextLine();
        truck.remove(d);
        System.out.println("Deletion Successfull you can see!");
        System.out.println(truck);
    }

public void OwnerInfo() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Your Information:");
        
        System.out.print("Name: ");
        this.name = scanner.nextLine();

        System.out.print("Father's Name: ");
        this.fatherName = scanner.nextLine();

        System.out.print("ID Card Number: ");
        this.idCardNumber = scanner.nextLine();

        System.out.print("Nationality: ");
        this.nationality = scanner.nextLine();

        System.out.print("Email: ");
        this.email = scanner.nextLine();

        System.out.print("Phone Number: ");
        this.phoneNumber = scanner.nextLine();
    }
}
        

