/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Areej Fatima
 */
 abstract public class Vehicle {
   public String name;
   public double price;
   public double mileage;

    public int count;
    
    public Vehicle( String name,double price,double mileage,int count) {
        
        this.mileage = mileage;
        this.price = price;
        this.name = name;
        this.count = count;
    }
    
    
    abstract void view();

    
}
