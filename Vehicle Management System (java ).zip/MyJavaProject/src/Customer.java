/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author Areej Fatima
 */
public class Customer {
    public String name;
    public String fatherName;
    public String idCardNumber;
    public String nationality;
    public String email;
    public String phoneNumber;

    public void CustomerInfo() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Customer Information:");
        
        System.out.print("Name: ");
        this.name = scanner.nextLine();

        System.out.print("Father's Name: ");
        this.fatherName = scanner.nextLine();

        System.out.print("ID Card Number: ");
        this.idCardNumber = scanner.nextLine();

        System.out.print("Nationality: ");
        this.nationality = scanner.nextLine();

        System.out.print("Email: ");
        this.email = scanner.nextLine();

        System.out.print("Phone Number: ");
        this.phoneNumber = scanner.nextLine();
    }
}
