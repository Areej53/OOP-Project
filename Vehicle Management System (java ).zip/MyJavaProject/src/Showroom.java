/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author Areej Fatima
 */
public class Showroom {
    public Customer customer;
    private Owner owner;
    boolean exitLoop = false;
    public Showroom() {
        this.customer = new Customer();
        this.owner = new Owner();

    }
   private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "adminpass";

    public static void displayMenu() {
         Showroom showroom = new Showroom();
        System.out.println("Welcome to the Vehicle Showroom!");

        Scanner scanner = new Scanner(System.in);
        boolean exitLoop = false;

        while (!exitLoop) {
            System.out.println("Are you a Customer or an Admin? (Type 'customer', 'admin', or 'exit' to quit): ");
            String userType = scanner.nextLine().toLowerCase();

            switch (userType) {
                case "customer":
                    System.out.println("Welcome, Customer!");
                    showroom.customer.CustomerInfo();
                    System.out.println("Select 'car', 'truck', or 'exit' to quit:");
                    String vehicleType = scanner.nextLine().toLowerCase();

                    switch (vehicleType) {
                        case "car":
                            displayCarMenu();
                            break;
                        case "truck":
                            displayTruckMenu();
                            break;
                        case "exit":
                            exitLoop = true;
                            break;
                        default:
                            System.out.println("Invalid input. Please enter 'car', 'truck', or 'exit'.");
                            break;
                    }
                    break;
                    
                case "admin":
                    System.out.println("Please log in as Admin.");
                   
                    System.out.print("Username: ");
                    String username = scanner.nextLine();

                    System.out.print("Password: ");
                    String password = scanner.nextLine();

                    if (username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
                        System.out.println("Login successful as Admin.");
                        
                         showroom.owner.OwnerInfo(); 
                        displayCarMenu();
                         System.out.println("Select 'car', 'truck', or 'exit' to quit:");

                        String adminChoice = scanner.nextLine().toLowerCase();

                        switch (adminChoice) {
                            case "car":
                                System.out.println("Select 'add', 'delete', or 'exit' to quit:");
                                String carAdminChoice = scanner.nextLine().toLowerCase();

                                switch (carAdminChoice) {
                                    case "add":
                                        showroom.owner.addcar();
                                        break;
                                    case "delete":
                                        showroom.owner.deletecar();
                                        break;
                                    case "exit":
                                        break;
                                    default:
                                        System.out.println("Invalid input. Please enter 'add', 'delete', or 'exit'.");
                                        break;
                                }
                                break;
                            case "truck":
                                   displayTruckMenu();
                                System.out.println("Select 'add', 'delete', or 'exit' to quit:");
                                String truckAdminChoice = scanner.nextLine().toLowerCase();

                                switch (truckAdminChoice) {
                                    case "add":
                                        showroom.owner.addtruck();
                                        break;
                                    case "delete":
                                        showroom.owner.deletetruck();
                                        break;
                                    case "exit":
                                        break;
                                    default:
                                        System.out.println("Invalid input. Please enter 'add', 'delete', or 'exit'.");
                                        break;
                                }
                                break;
                            case "exit":
                                break;
                            default:
                                System.out.println("Invalid input. Please enter 'car', 'truck', or 'exit'.");
                                break;
                        }
            
                     
                        
                    } else {
                        System.out.println("Login failed. You are logged in as a Customer.");
                        viewCars();
                    }
                    break;
                case "exit":
                    exitLoop = true;
                    break;
                default:
                    System.out.println("Invalid user type. Please select 'customer', 'admin', or 'exit'.");
                    break;
            }
        }
    }
    

    private static void viewCars() {
        Car car1 = new Car("Toyota Camry", 25000, 30.5, 3);
        Car car2 = new Car("Honda Civic", 22000, 28.8, 2);
        Car car3 = new Car("Toyota Corolla", 23000, 29.5, 4);
        Car car4 = new Car("Suzuki Grandi", 20000, 27.0, 1);
        Car car5 = new Car("Honda City", 24000, 31.0, 3);

        System.out.println("Available Cars:");
        System.out.println(car1.name + " | Price: $" + car1.price + " | Mileage: " + car1.mileage + " | Count: " + car1.count);
        System.out.println(car2.name + " | Price: $" + car2.price + " | Mileage: " + car2.mileage + " | Count: " + car2.count);
        System.out.println(car3.name + " | Price: $" + car3.price + " | Mileage: " + car3.mileage + " | Count: " + car3.count);
        System.out.println(car4.name + " | Price: $" + car4.price + " | Mileage: " + car4.mileage + " | Count: " + car4.count);
        System.out.println(car5.name + " | Price: $" + car5.price + " | Mileage: " + car5.mileage + " | Count: " + car5.count);
    }
    
    
    private static void displayCarMenu() {
        System.out.println("Car Menu:");

        Car car1 = new Car("Toyota Camry", 25000, 30.5, 3);
        Car car2 = new Car("Honda Civic", 22000, 28.8, 2);
        Car car3 = new Car("Toyota Corolla", 23000, 29.5, 4);
        Car car4 = new Car("Suzuki Grandi", 20000, 27.0, 1);
        Car car5 = new Car("Honda City", 24000, 31.0, 3);

        System.out.println("Available Cars:");
        System.out.println(car1.name + " | Price: $" + car1.price + " | Mileage: " + car1.mileage + " | Count: " + car1.count);
        System.out.println(car2.name + " | Price: $" + car2.price + " | Mileage: " + car2.mileage + " | Count: " + car2.count);
        System.out.println(car3.name + " | Price: $" + car3.price + " | Mileage: " + car3.mileage + " | Count: " + car3.count);
        System.out.println(car4.name + " | Price: $" + car4.price + " | Mileage: " + car4.mileage + " | Count: " + car4.count);
        System.out.println(car5.name + " | Price: $" + car5.price + " | Mileage: " + car5.mileage + " | Count: " + car5.count);
    }

    private static void displayTruckMenu() {
        System.out.println("Truck Menu:");

        Truck truck1 = new Truck("Ford F-150", 35000, 20.5, 5);
        Truck truck2 = new Truck("Chevrolet Silverado", 33000, 19.8, 3);
        Truck truck3 = new Truck("Dodge Ram", 32000, 21.0, 2);

        System.out.println("Available Trucks:");
        System.out.println(truck1.name + " | Price: $" + truck1.price + " | Mileage: " + truck1.mileage + " | Count: " + truck1.count);
        System.out.println(truck2.name + " | Price: $" + truck2.price + " | Mileage: " + truck2.mileage + " | Count: " + truck2.count);
        System.out.println(truck3.name + " | Price: $" + truck3.price + " | Mileage: " + truck3.mileage + " | Count: " + truck3.count);
    }
    
    
    
}
