/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java .util.*;
import java.io.*;
/**
 *
 * @author Areej Fatima
 */
public class VMS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Showroom.displayMenu(); // Call the displayMenu() method from Showroom class

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter 'car' or 'truck': ");
        String vehicleType = scanner.nextLine().toLowerCase();
        if (vehicleType.equals("car")){
        Car car1 = new Car("Toyota Camry", 25000, 30.5, 3);
        Car car2 = new Car("Honda Civic", 22000, 28.8, 2);
        Car car3 = new Car("Toyota Corolla", 23000, 29.5, 4);
        Car car4 = new Car("Suzuki Grandi", 20000, 27.0, 1);
        Car car5 = new Car("Honda City", 24000, 31.0, 3);

        Car.addCar(car1);
        Car.addCar(car2);
        Car.addCar(car3);
        Car.addCar(car4);
        Car.addCar(car5);

        car1.view();

}
        else if (vehicleType.equals("truck")) {
        Truck truck1 = new Truck("Ford F-150", 35000, 20.5, 5);
        Truck truck2 = new Truck("Chevrolet Silverado", 33000, 19.8, 3);
        Truck truck3 = new Truck("Dodge Ram", 32000, 21.0, 2);

        Truck.addTruck(truck1);
        Truck.addTruck(truck2);
        Truck.addTruck(truck3);

        truck1.view(); 
        // TODO code application logic here
    }
else {
            System.out.println("Invalid input. Please enter 'car' or 'truck'.");
        }
    }
    
}
