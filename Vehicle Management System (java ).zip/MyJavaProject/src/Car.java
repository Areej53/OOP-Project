/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Areej Fatima
 */
public class Car extends Vehicle  {
    private static List<Car> availableCars = new ArrayList<>();
    public Car( String name,double price,double mileage,int count)
    {
        super(name,price,mileage,count);
    }
       
   public  void view()
    {
       System.out.println("Available Cars:");
        for (Car car : availableCars) {
            System.out.println(car.name);
        }

        Scanner scanner = new Scanner(System.in);
        String action;

        do {
            System.out.println("Do you want to buy or rent a car? (Type 'buy' or 'rent', or 'exit' to quit):");
            action = scanner.nextLine().toLowerCase();

            if (action.equals("exit")) {
                System.out.println("Thank you for using the system. Goodbye!");
                return; // Exit the method and stop the loop
            }

            if (action.equals("rent") || action.equals("buy")) {
                System.out.println("Enter the car name:");
                String carName = scanner.nextLine();

                boolean carFound = false;
                for (Car car : availableCars) {
                    if (car.name.equalsIgnoreCase(carName)) {
                        if (action.equals("rent")) {
                            if (car.count > 0) {
                                System.out.println("The car '" + car.name + "' is available for rent.");
                                // Simulating the booking process
                                car.count--;
                                System.out.println("Car booked for rent. Enjoy your ride!");
                            } else {
                                System.out.println("Sorry, the car '" + car.name + "' is not available for rent. You can go for another car .");
                            }
                        } else if (action.equals("buy")) {
                            System.out.println("The car '" + car.name + "' is available for sale.");
                        }
                        carFound = true;
                        break;
                    }
                }
                if (!carFound) {
                    System.out.println("Sorry, the car '" + carName + "' is not available.");
                }
            } else {
                System.out.println("Invalid action. Please type 'buy' or 'rent', or 'exit' to quit.");
            }
        } while (true); // Loop will continue until 'exit' is entered
    }

    public static void addCar(Car car) {
        availableCars.add(car);
    }
}



    
    

